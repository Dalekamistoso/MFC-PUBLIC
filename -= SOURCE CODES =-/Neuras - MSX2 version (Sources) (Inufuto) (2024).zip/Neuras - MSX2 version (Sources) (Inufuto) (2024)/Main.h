extern word Score;
extern word HiScore;
extern byte RemainSolverCount;

extern void AddScore(word pts);