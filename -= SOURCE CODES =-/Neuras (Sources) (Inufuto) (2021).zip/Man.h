extern Actor Man;

extern void InitMan();
extern void MoveMan();
extern void MoveManOnLift(ptr<Movable> pLift);
extern void FallMan();
extern void HitMan(ptr<Movable> pMovable);
extern void LooseMan();
