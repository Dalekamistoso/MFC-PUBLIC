extern Actor[] Monsters;
extern byte MonsterCount;

extern void InitMonsters();
extern void MoveMonsters();
extern void MoveMonstersOnLift(ptr<Movable> pLift);
extern void FallMonsters();
