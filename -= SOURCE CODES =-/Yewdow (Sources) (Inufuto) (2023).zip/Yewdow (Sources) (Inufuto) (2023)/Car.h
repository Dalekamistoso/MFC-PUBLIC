#include "Actor.h"

extern Actor[] Cars;
extern ptr<Actor> pLostCar;

extern void InitCars();
extern void MoveCars();
extern void LooseCar();