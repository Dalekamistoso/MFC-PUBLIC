#include "Actor.h"

extern Actor Man;

extern void InitMan();
extern void MoveMan();
extern bool HitMan(ptr<Movable> pMovable);