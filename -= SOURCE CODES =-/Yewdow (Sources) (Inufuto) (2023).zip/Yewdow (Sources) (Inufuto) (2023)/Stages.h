constexpr byte StageCount = 8;
constexpr byte MaxCarCount = 2;
constexpr byte MaxMonsterCount = 2;
