Place these files under the lib directory of your z88dk installation. In my case, I installed from source, and they are under /usr/local/share/z88dk/lib.
