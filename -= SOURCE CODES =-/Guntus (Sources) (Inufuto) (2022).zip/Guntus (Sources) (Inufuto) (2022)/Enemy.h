extern byte EnemyCount;

extern bool HitBulletEnemy(byte bulletX, byte bulletY, byte enemyX, byte enemyY);
