extern byte RndIndex;

extern byte Rnd();
extern byte Abs(byte a, byte b);
extern sbyte Sign(byte from, byte to);
