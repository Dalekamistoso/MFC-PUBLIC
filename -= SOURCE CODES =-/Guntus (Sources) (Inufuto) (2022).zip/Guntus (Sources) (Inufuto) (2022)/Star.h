extern byte CharOffset;

extern void MoveStars();
extern void DrawStars(word vram);
