constexpr byte StageCount = 8;
extern const Stage[] Stages;
