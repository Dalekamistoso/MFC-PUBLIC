
extern void InitSound();

extern void Sound_Fire();
extern void Sound_SmallBang();
extern void Sound_LargeBang();
extern void Sound_Up();
extern void Sound_Start();
extern void Sound_GameOver();
extern void StartBGM();
extern void StopBGM();
