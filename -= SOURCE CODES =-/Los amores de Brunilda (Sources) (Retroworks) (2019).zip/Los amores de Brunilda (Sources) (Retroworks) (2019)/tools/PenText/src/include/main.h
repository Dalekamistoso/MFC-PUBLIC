/*
PenText

Text compressor for z80

*/
#include <iostream>
#include <string.h>
#include "../include/parser.h"
#include "../include/PenText.h"

using namespace std;
