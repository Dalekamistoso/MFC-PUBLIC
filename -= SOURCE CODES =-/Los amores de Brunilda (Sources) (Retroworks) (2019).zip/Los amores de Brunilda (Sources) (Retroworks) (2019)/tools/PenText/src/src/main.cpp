#include "../include/main.h"


int main(int argc, char *argv[])
{
    PenText *program;    Parser *parser;    int Return;    program = new PenText;    parser = new Parser (argc, argv);    Return = program->Run(parser);    delete parser;    delete program;    return Return;
}
