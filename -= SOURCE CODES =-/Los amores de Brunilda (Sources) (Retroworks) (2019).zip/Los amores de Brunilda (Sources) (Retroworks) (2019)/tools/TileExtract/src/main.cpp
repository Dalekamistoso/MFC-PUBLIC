#include "main.h"#include <string.h>
int main(int argc, char *argv[]){    TileExtract *program;    Parser *parser;    int Return;    program = new TileExtract;    parser = new Parser (argc, argv);    Return = program->Run(parser);    delete parser;    delete program;    return Return;
}
