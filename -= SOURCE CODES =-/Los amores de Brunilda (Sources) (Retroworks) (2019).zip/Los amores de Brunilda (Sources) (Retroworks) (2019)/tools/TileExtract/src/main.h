/* Version log
V.1.0 -> First version releasedV.1.1 -> Includes total tiles found in case of reach maximum limit (256)
V.1.2 -> Supertiles can be repeated*/#include "parser.h"#include "tileextract.h"using namespace std;

