#include "Movable.h"

extern byte MonsterCount;
extern Movable[] Monsters;

extern void InitMonsters();
extern void FallMonsters();
extern void MoveMonsters();
