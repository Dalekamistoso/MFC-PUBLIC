#include "Movable.h"

extern Movable Man;

extern void InitMan();
extern void FallMan();
extern void MoveMan();
extern void LooseMan();
