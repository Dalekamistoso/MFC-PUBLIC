I NEED SPEED - Source Code
--------------------------
This source code and resources are freely released for educational purposes. If you use some of the code for your own projects, it would be nice if you credit the author(s).

COMMON STUFF
------------
__tools: some tools needed to compile the source, or to handle some special data. Also a .txt file linking all needed tools to make the compilations (not included to avoid either taking too much space or violating licenses).

_docs: changelog and some other stuff.

_music: all .wyz files for WYZtracker, the .pt3 file for the Vortex Tracker

_tracks: all tracks in TileStudio format (.tsp), the exported maps (map_0x.dat), source files adding checkpoints and initial positions data (fase_0x.asm) and compiled tracks using that source (fase_0x.dat)

SPECTRUM SOURCE
---------------
Included in directory zx_src, includes:

_art: original artwork. Compressed screens and static graphics data files are derived from here. Special images not included ;-) (but they're still compressed in the bindata folder)

_orfeus: here you can find the Orfeus snapshot for the 48k menu music, the song data compiled by Orfeus in a .tap file, and the tool to cut the relevant parts to be included in the game.

_sevs: ingame graphics for the cars and background, in SevenuP's format, to be processed for the use in CezBlocks engine. After generating the files data.asm and labels.asm, the labels are futher optimized disabling characters as guided by MAPA_SEVS.txt

bindata: binary data included in the game, mostly compressed.

code\cezhalfblocks48optflex.asm:CezBlocks routines, specially crafted for the game.
code\chars.asm: 		some char printing routines.
code\deexo.asm: 		optimized exomizer decompression routine.
code\macro.asm: 		definition of ALIGN macro.
code\struct.asm: 		structure of car and camera data sets, to be used with index registers

data\brujula.asm: 		compass graphic.
data\championships.asm: 	championship data.
data\charset.asm: 		equivalence table for characters.
data\data.asm: 			CezBlocks graphic data, reorganized by hand.
data\labels.asm: 		CezBlocks labels data, optimized by hand.
data\pautas.asm: 		Instruments & sound tables for the WYZPlayer.
data\spd_table.asm: 		Speeds tables for the different categories.
data\tablas.asm: 		Several tables, including tiles, camera positioning, speeds, collision, turning, keys and starting positions.
data\velocidad.asm: 		Speedometer graphics.

creatzx.txt: 			Describes the blocks for the instzx tool to generate the final .tzx file.
ineed.scr: 			I Need Speed loading screen.
ins.asm: 			Main code file
ins128.asm: 			Most 128k extra code.
ins3.asm: 			Code & data to be placed in page 3, includes the special endings and the check to know if they must be shown.
labels.lst: 			Addresses of tile labels, taken from a compilation without easter egg, needed for the compilation with easter egg.
make.bat: 			Batch file to build the whole project in windows.
messages.txt: 			All text messages, in I Need Speed special format.
orfeus.asm: 			Modified orfeus code.
variables.asm: 			Variables.
vortex.asm: 			Vortex player, to play the menu music (PT3 format).
wyzplayer.asm: 			WYZplayer, to play the ingame & interlude music (WYZ format).


MSX SOURCE
----------
Included in directory src_zx, includes:

_art: original artwork in nMSXTiles format. Compressed screens and static graphics data files are derived from here. Special image not included ;-) (but it's still compressed in the bindata folder)

_compresseddata: some data files that will be compressed later, including screen designs, a cutted down PT3 file to be used with Sapphire's PT3 player, and some binaries.

bindata: binary data included in the game, mostly compressed.

code\dump.asm: 			main dump routine, updates the screen every 0.1 seconds.
code\deexo.asm: 		optimized exomizer decompression routine.
code\macro.asm: 		definition of ALIGN macro.
code\struct.asm: 		structure of car and camera data sets, to be used with index registers.

data\background.asm: 		map tiles, optimized by hand.
data\car_colors.asm:		color mix table, indicates for each car byte how should it be mixed with the background.
data\car_graph.asm:		characters for each car frame.
data\car_tiles.asm:		car graphics.
data\championships.asm: 	championship data.
data\charset.asm: 		equivalence table for characters.
data\color.asm:			background tiles colors.
data\colorsets.asm:		colorsets for text messages.
data\mcolors.asm:		packed marker color indicators.
data\messages.txt: 		All text messages, in I Need Speed special format.
data\pautas.asm: 		Instruments & sound tables for the WYZPlayer.
data\spd_table.asm: 		Speeds tables for the different categories.
data\spriteheight.asm:		Height offsets for tyre sprites.
data\tablas.asm: 		Several tables, including tiles, camera positioning, speeds, collision, turning, keys and starting positions.
data\tiles.asm:			background tiles graphics.
data\velocidad.asm: 		Speedometer graphics.

ins.asm: 			Main code file for ROM pages 0 and 1.
ins_orig.asm:			Non-bugfixed version, replacing ins.asm with this one, you can generate the cartridge version of the ROM.
ins2.asm:			Data file for ROM page 2.
make.bat:			Batch file to build the whole project in Windows.
pt3player.asm:			Sapphire's PT3 player, to play the menu music (PT3 format).
variables.asm:			Variables, self-modified code and messages.
wyzplayer.asm: 			WYZplayer, to play the ingame & interlude music (WYZ format).