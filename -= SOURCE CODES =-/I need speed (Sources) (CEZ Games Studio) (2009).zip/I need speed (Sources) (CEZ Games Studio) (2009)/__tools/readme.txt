TOOLS
-----
For MSX compilation, you only need this:
exomizer 2: 		http://hem.bredband.net/magli143/exo/
exoopt: 		included, source here http://www.speccy.org/metalbrain/exo_v3.zip
pasmo: 			http://www.speccy.org/pasmo/

For Spectrum compilation, the same MSX ones and also:
instzx: 		included, with source
snip: 			http://www.ibsensoftware.com/download.html

Extra tools to work with the resources:
charcomp: 		included, with source
SevenuP:		http://www.speccy.org/metalbrain
nMSXTiles:		http://code.google.com/p/nmsxtiles/
TileStudio: 		http://tilestudio.sourceforge.net/
WYZTracker:		http://augusto.ruiz.googlepages.com/WYZTracker.0.2.19.rar