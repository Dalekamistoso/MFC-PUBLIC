Eu estou liberando este código fonte sem me comprometar em dar qualquer suporte. Utilize este material como forma de aprender a programar utilziando o MPAGD. Você deve baixar o programa, descompactar em uma pasta (de preferência sem espaços de com no máximo 8 caracters no nome), descompactar esse código fonte em uma sub pasta e abrir com o MPAGD. Se não funcionar tente criar um novo projeto e depois copiar o conteúdo deste projeto renomeando os arquivos e substituindo pelos deste projeto. Você pode abrir o arquivo facilmente ".AGD" e vários outros aqrquivos do projeto com o bloco de notas e ver/alterar seu conteúdo e depois compilar utilziando os compiladores do MPAGD (não providos por mim). Para mais ajuda procure os foruns dedicados a programação de AGD e MPAGD.

I am releasing this source code without committing to any support. Use this material as a way to learn to program using MPAGD. You must download the program, unzip it in a folder (preferably without spaces with a maximum of 8 characters in the name), unzip this source code in a sub folder and open it with MPAGD. If it doesn't work, try to create a new project and then copy the contents of this project, renaming the files and replacing them with this project. You can easily open the ".AGD" file and several other project files with notepad and view/change their contents and then compile using MPAGD compilers (not provided by me). For more help look for the forums dedicated to programming AGD and MPAGD.

Links:
https://jonathan-cauldwell.itch.io/multi-platform-arcade-game-designer
https://www.youtube.com/watch?v=9evsT7vL0xM
https://www.minilopretro.com/post/let-s-create-an-mpagd-game-part-1-getting-started
https://arcadegamedesigner.proboards.com/
