extern Actor Man;

extern void InitMan();
extern void MoveMan();
extern void LooseMan();