extern void InitDestructions();
extern void StartDestruction(byte column, byte floor);
extern void UpdateDestructions();
