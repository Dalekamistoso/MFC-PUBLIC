DMZ001 - JumpinG ( The Tutorial Game )
RELEASED 25 Jan 2012
Presented to the MSXdev'11 contest
Jose Vila Cuadrillero
(c) 2011 DIMENSION Z Retro Video Games
www.dimensionzgames.com