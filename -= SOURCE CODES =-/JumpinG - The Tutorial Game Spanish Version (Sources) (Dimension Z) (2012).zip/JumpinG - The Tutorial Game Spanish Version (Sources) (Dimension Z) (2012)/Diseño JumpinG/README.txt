DMZ001 - JumpinG ( The Tutorial Game )
RELEASED 25 Jan 2012
Presented to the MSXdev'11 contest
Jose Vila Cuadrillero
(c) 2011 DIMENSION Z Retro Video Games
www.dimensionzgames.com

DIRECTORY: Mapeado_nMSXtiles
All screens of the game with nMSXtiles.

DIRECTORY: nMSXtiles_063
nMSXtiles Program for managing the screens

DIRECTORY: Projectos nMSXtiles
All Projects of the game to work with nMSXtiles.

DIRECTORY: Sprites
All sprites of the game, designed with tinysprite.
to load it using the Paste option.

DIRECTORY: tinysprite_0.4.6
TinySprite 0.4.6 Program by Rafael Jannone.

DIRECTORY: WYZ Modulos
All Projects music & SFXs for the WYZTracker

DIRECTORY: WYZTracker.0.2.19
WYZTracker.0.2.19 Program by Augusto Ruiz
