extern void Init();
// extern void Fin();
extern void WaitTimer(byte t);
