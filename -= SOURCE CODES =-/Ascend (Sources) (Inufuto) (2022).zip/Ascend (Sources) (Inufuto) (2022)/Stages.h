constexpr byte StageCount = 10;
constexpr byte MaxMonsterCount = 9;
constexpr byte MaxBlockCount = 7;
constexpr byte MaxMapHeight = 15;

extern const Stage[] Stages;
