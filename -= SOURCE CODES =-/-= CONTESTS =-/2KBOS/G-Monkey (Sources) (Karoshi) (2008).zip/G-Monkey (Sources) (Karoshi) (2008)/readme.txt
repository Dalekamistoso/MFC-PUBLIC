----------------------------------------------------------------------------
G-MONKEY
----------------------------------------------------------------------------
(c) Karoshi Corp. 2008 - Coded by Eduardo Robsy Petrus
----------------------------------------------------------------------------
For assembling instructions, game controls and other informations, please
read carefully the source code file, G-MONKEY.ASM
----------------------------------------------------------------------------
Included files
----------------------------------------------------------------------------
 readme.txt	- this information file
 g-monkey.pdf	- cassette inlay for the game
 g-monkey.asm	- source code of the game
 g-monkey.bin	- bloadable binary file (contest version)
 g-monk8k.bin   - bloadable binary file for MSX with only 8 KB of RAM
 g-monkey.cas	- cassette image to use with emulators
 g-monkey.wav	- audio file to load using the cassette interface
 g-monkey.rom	- 8KB ROM version of the game
 g-monkey.txt	- asMSX assembly information output
 asmsx		- Linux executable of the assembler (v.0.15 beta)
 asmsx.exe	- Windows executable of the assembler (v.0.15 beta)
----------------------------------------------------------------------------
2KBOS game development contest information
----------------------------------------------------------------------------
What is 2KBOS?
----------------------------------------------------------------------------
A new contest has been announced at the Karoshi forum! This new contest is
a mini-game development contest that aims to provide a collection of Open 
Source 2KB games with commented code that will encourage new developers to
join and will provide a valuable resource to improve assembly programming 
skills. The contest goal is to get full Open Source games for MSX, the prize
will thus be the availability of the sources of all those games, commented
by the authors.

The basic rules of this contest:

    * Every game genre and theme is allowed
    * Start adress: 0C000h (it must work on every MSX with 16KB RAM or more)
    * It must load with a "BLOAD" command from BASIC
    * It must return to BASIC with a RET
    * Max file size: 2055 bytes (2048 for the game + 7 bytes for the header)
    * Submitting deadline: 26th of June 2008 at 23:59:59

When the contest is over, a PDF will be published including all sources of
the games with comments by the authors, and a ROM version with a menu will 
be built in order to enjoy the minigames in the most comfortable way.

For more information, please visit http://www.karoshicorp.com
----------------------------------------------------------------------------
