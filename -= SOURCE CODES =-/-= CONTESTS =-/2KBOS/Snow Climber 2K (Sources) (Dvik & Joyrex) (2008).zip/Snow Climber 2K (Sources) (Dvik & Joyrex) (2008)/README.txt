


                        Snowclimber 2K
              
                   (c) 2003 Vincent van Dam
                     (c) 2008 dvik&joyrex
            
            
            
            
INTRODUCTION
============

Snowclimber 2K is a game developed for Concurso 2Kb Opensource 2008.

The objective of the game is  to get your pinguin to  the top of the
hill as quickly as possible.   Unfortunately it snows outside,   and
sometimes a strong wind blows.   When this wind blows,   you can not
climb, the wind will blow you down. To prevent this you can duck and
wait untill the wind drops.

The game was initially released in the MRC Snowfall challenge,   but
this is an enhanced version that support both a one and a two player
game mode. The game is also optimized to fit the size limitations of
Concurso 2Kb Opensource 2008.


CONTROLS
========

PLAYER 1: Use cursor keys or joystick 1 to move up. Use space bar or
          fire button to duck.

PLAYER 2: Use joystick 2 to move up. Use fire button to duck.


LOADING
=======

The game can be loaded from disk or from tape. With the game on your
medium of choise, type

    BLOAD"SNOWCLMB.BIN",R
    
    
SYSTEM REQUIREMENTS
===================

Snowclimber 2K  is designed for MSX1 machines  with at least 16kB of
RAM. 


COMPILING
=========

The source code package comes with a Makefile  but the source can be
compiled  standalone  as well.    Compiling the  game  requires  the 
following tools from xl2s (www.xl2s.tk):

    sjasm   v0.39g
    pletter v0.4a

To compile it from a standard dos shell, type the following:

    sjasm.exe snowclmb.asm
    pletter.exe 1 snowclmb.bin
    sjasm.exe loader.asm
    
This produces the file  LOADER.BIN  which can be loaded  on the MSX.
THe file can be renamed SNOWCLMB.BIN to get the exact output name as
the submitted entry.
