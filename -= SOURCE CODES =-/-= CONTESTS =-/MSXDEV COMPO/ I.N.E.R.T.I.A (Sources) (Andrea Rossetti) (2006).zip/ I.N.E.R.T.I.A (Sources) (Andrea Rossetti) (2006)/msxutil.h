#ifndef ___MSXUTIL_H___
#define ___MSXUTIL_H___

char text_choice(int msgs, int chosen, char *title, char *msg[]);

#endif
