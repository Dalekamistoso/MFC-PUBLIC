#ifndef ___MSXVIDEO_H___
#define ___MSXVIDEO_H___

#include "msx.h"

#define SPRITE8X8      8
#define SPRITE16X16   32

#define SPRITE_NO_ZOOM 0
#define SPRITE_ZOOM    1

void screen_color(char fg, char bg, char bd);
char vpeek(int address);
void vpoke(int address, char value);
void vpoke_block(int address, char* block, int size);
void wait_retrace();

void screen1_setup_mode();
void screen1_setup_sprites(char spritesize, char zoom);
void screen1_setup_chars();

void screen1_sprite_profile(char number, unsigned char* profile, char spritesize);
void screen1_sprite_put(char number, char xpos, char ypos, char color);

void screen1_setup_back();
void screen1_back_rotate(char x);

#endif
