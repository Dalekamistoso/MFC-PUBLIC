void sound_set(char reg, char val);
char sound_get(char reg);

