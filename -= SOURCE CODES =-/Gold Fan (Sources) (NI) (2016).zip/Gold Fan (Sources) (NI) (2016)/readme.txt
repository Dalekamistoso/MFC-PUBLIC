This source can be compiled with ccZ80++ and Tabmegx
