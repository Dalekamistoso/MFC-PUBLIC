// constexpr byte Monster_Weak = 0x40;

extern byte MonsterCount;
extern Actor[] Monsters;

extern void InitMonsters();
extern void StartMonsters();
extern void MoveMonsters();
// extern void WeakenMonsters();
