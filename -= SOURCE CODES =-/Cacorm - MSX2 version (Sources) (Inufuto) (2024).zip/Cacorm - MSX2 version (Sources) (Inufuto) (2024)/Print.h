extern word PrintByteNumber3(word address, byte b);
extern word PrintByteNumber2(word address, byte b);
extern word PrintNumber5(word address, word w);
extern word PrintNumber3(word address, word w);
