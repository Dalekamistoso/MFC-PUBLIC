To compile this example you need a pt3 module with first 99 bytes stripped. 
Rename it to MUSIC.99 and place it on the same directory as these files, then 
you can compile by typing

asMSX example.asm

Hope you find useful this code
--
SapphiRe
