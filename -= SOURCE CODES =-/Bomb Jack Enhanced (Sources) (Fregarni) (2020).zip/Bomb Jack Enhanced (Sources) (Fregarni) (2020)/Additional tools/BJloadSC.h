// tileset menu
// pattern data
// Size= 6144
unsigned char tablaPatrones[]={};

// color data
// Size= 6144
unsigned char tablaColor[]={};

// VRAM address= 1800h
// start x=0 y=0
// end   x=31 y=23
//Original size= 768
unsigned char tablaNombres[]={};